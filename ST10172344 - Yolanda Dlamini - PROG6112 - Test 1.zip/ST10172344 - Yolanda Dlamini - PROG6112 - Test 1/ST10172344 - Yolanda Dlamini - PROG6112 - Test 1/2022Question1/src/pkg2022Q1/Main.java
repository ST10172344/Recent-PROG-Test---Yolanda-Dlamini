package pkg2022q1;

public class Main {
//dimensional arrays
    public static int[][] sales = {
        {4, 8, 6},
        {5, 4, 2},
        {4, 2, 8}
    };
    public static String[] hospitals = {"HOSPITAL 1", "HOSPITAL 2", "HOSPITAL 3"};
    public static int[] total = new int[3];
    public static int[] monthly_total = new int[3];
    
    public static double[] AVG = new double[3];
    public static double[] monthly_AVG = new double[3];
    
    public static int totalAll = 0;
     public static double AVGAll = 0.00;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        calculateTotals();
        calculateAverage();
        generateReport();
    }

    
    //calculation of totals
    public static void calculateTotals() {
        int _total = 0;
        for (int i = 0; i < sales.length; i++) {
            _total = 0;
            for (int j = 0; j < sales[i].length; j++) {
                _total = _total + sales[i][j];
            }
            total[i] = _total;
            totalAll += total[i];
        }

        for (int i = 0; i < 3; i++) {
            _total = 0;
            for (int j = 0; j < sales.length; j++) {
                _total = _total + sales[j][i];
            }
            monthly_total[i] = _total;
        }
    }

    // calculation of average
    public static void calculateAverage() {
        double _AVG = 0.0;
        for (int i = 0; i < sales.length; i++) {
            _AVG = 0.0;
            for (int j = 0; j < sales[i].length; j++) {
                _AVG = (_AVG + sales[i][j]);
            }
            AVG[i] = _AVG/3;
            
        }

        for (int i = 0; i < 3; i++) {
            _AVG = 0.0;
            for (int j = 0; j < sales.length; j++) {
                _AVG = (_AVG + sales[j][i]);
            }
            monthly_AVG [i] = _AVG/3;
        }
    }
    

    //printing out the report
    public static void generateReport() {
        System.out.println("*********************************************************************\n"
                + "Health Inspection Report"
                + "\n*********************************************************************");
        System.out.println("\t\tJAN\tFEB\tMAR\tTOTAL\tAverage");
        for (int i = 0; i < sales.length; i++) {
        System.out.print(hospitals[i] + "\t");
        for (int j = 0; j < sales[i].length; j++) {
        System.out.print(sales[i][j] + "\t");
        }

        System.out.print(total[i] + "\t" +  AVG[i]);
        System.out.println("");
        System.out.println("");
        }

        System.out.println("*********************************************************************");
        System.out.print("MONTHLY TOTAL" + "\t");
        for (int i = 0; i < monthly_total.length; i++) {
        System.out.print(monthly_total[i] + "\t");
        }
        System.out.print(totalAll + "\t");
        System.out.println("\n*********************************************************************");

    }
}
