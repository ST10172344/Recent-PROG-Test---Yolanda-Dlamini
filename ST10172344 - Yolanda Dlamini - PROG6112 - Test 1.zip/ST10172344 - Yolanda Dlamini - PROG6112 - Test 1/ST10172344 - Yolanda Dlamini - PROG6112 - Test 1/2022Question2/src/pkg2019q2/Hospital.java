package pkg2019q2;
import java.util.Scanner;

public class Hospital extends Inspection {

    public Hospital() {
    }

    public Hospital(
            String _HospitalName, 
            String _HospitalLocation, 
            int    _year, 
            double _rating) {
        
        super(  _HospitalName, 
                _HospitalLocation, 
                _year, 
                _rating);
    }
    @Override
    public void print_report() {
        double discount = 0;
        if (getYear() >= 3) {    
        }
        double total = getRating()+0; 
        System.out.println(" Inspection needed");
        
        
        System.out.println("**********************************************" +
                "\nHOSPITAL INSPECTION REPORT\n**********************************************" + 
                "\nHospital location :"  + getHospitalName() + 
                "\nHospital Name: " + getHospitalLocation()
                
                + "\nYears since last inspected: " + getYear()
                + "\nInspection needed (?/10): " + total
                +  "\n**********************************************");
    }

    public void input() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter hospital location: ");
        setHospitalName(input.nextLine());
        
        System.out.print("Enter hospital name: ");
        setHospitalLocation(input.nextLine());
        
        System.out.print("Enter years since last inspected: ");
        setYear(input.nextInt());
        
        System.out.print("Inspection requirementout of 10: ");
        setRating(input.nextDouble());
    }
}
