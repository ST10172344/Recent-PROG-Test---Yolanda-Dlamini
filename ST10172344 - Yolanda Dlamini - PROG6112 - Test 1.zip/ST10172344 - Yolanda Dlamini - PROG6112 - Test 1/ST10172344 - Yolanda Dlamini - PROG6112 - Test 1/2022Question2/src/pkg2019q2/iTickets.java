
package pkg2019q2;

public interface iTickets {
    public abstract void print_report();
}
