
package pkg2019q2;

public class Main {
    
    public static void main(String[] args) {
        // TODO code application logic here
        Hospital hospital_entry =  new Hospital();
        hospital_entry.input();
        hospital_entry.print_report();
    }
    
}
