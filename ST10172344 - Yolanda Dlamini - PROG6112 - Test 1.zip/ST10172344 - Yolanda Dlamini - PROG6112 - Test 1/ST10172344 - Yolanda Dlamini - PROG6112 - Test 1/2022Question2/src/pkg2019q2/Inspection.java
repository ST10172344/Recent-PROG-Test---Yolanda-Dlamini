
package pkg2019q2;

public abstract class Inspection implements iTickets{
    private String HospitalName;
    private String HospitalLocation;
    private int year;
    private double rating;
    
    public Inspection(){}
    public Inspection(
            String _HospitalName,
            String _HospitalLocation, 
            int    _year, 
            double _rating)
            
    {
        this.HospitalName =       _HospitalName;
        this.HospitalLocation =   _HospitalLocation;
        this.year =               _year;
        this.rating =              _rating;
    }

    public String getHospitalName() {
        return HospitalName;
    }

    public void setHospitalName(String HospitalName) {
        this.HospitalName = HospitalName;
    }

    public String getHospitalLocation() {
        return HospitalLocation;
    }

    public void setHospitalLocation(String HospitalLocation) {
        this.HospitalLocation = HospitalLocation;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
    
    
}
